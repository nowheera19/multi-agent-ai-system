# 🧠 BTC Trend Multi-Agent System
... (Full README content from previous message goes here. Shortened here for clarity.)