def plan(user_goal):
    return ["price_agent", "news_agent", "analysis_agent"]
