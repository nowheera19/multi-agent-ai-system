def analyze(price, news):
    change = price["usd_24h_change"]
    bearish_count = sum("fall" in a["title"].lower() or "down" in a["title"].lower() for a in news)
    sentiment = "Bearish" if change < 0 and bearish_count > 1 else "Bullish or Neutral"
    return f"24h Change: {change:.2f}%. Market Sentiment: {sentiment}."
