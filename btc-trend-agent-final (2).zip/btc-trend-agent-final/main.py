from agents import planner, price_agent, news_agent, analysis_agent

def run():
    print("🔎 Planning task flow...")
    tasks = planner.plan("Analyze Bitcoin trend")

    print("📊 Getting Bitcoin price...")
    price = price_agent.get_btc_price()
    print("Price:", price)

    print("\n📰 Fetching news...")
    news = news_agent.get_news()
    for i, a in enumerate(news): print(f"{i+1}. {a['title']}")

    print("\n📈 Analyzing trend...")
    result = analysis_agent.analyze(price, news)

    print("\n✅ Final Result:")
    print(result)

if __name__ == "__main__":
    run()
