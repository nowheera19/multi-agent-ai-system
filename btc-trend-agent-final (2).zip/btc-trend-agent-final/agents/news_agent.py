import requests, os
from dotenv import load_dotenv
load_dotenv()

def get_news():
    key = os.getenv("NEWS_API_KEY")
    url = f"https://newsapi.org/v2/everything?q=bitcoin&sortBy=publishedAt&apiKey={key}"
    response = requests.get(url)
    return response.json()["articles"][:5]
